package com.mygdx.game;

public class Cubo{
    float bucketX;
    float bucketY;

    public Cubo(float bucketX, float bucketY) {
        this.bucketX = bucketX;
        this.bucketY = bucketY;
    }
}