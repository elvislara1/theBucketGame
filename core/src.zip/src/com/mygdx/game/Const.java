package com.mygdx.game;

public class Const{
    //Utilizo constantes
    static final int VELOCIDAD_NIVEL_1 = 5;
    static final int VELOCIDAD_NIVEL_2 = 9;
    static final int VELOCIDAD_NIVEL_3 = 13;
}