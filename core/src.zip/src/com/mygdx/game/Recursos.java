package com.mygdx.game;

import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;

public class Recursos{
    static Sound dropWater;
    static Sound gOver;
    static Sound fallo;
    static Music rainMusic;
}