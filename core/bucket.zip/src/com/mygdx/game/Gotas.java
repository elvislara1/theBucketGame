package com.mygdx.game;

public class Gotas{
    float[] gX = new float[2];
    float[] gY = new float[2];
}